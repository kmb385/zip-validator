$(document).ready(function(){
	$(".delete-control-btn").click(function(){
		return window.confirm("Are you sure you want to delete the post?");
	});
});
