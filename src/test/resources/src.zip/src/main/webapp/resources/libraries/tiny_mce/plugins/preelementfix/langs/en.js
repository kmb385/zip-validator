tinyMCE.addI18n('en.preelementfix',{
  mei_remove_css_alias: 'Remove CSS alias'
});