$(document).ready(function() {
	
	$(".simple-list").ttSimpleList("degreeDetails");
	$(".date-picker").datepicker();
	$("input:first").focus();
});
