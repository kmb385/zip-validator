package org.tothought.data.entities.interfaces;

import java.util.Date;

public interface SkillDetail {

	
	public Integer getId();
	
	public String getUrl();
	
	public String getTitle();
	
	public Date getCreatedDt();
}
