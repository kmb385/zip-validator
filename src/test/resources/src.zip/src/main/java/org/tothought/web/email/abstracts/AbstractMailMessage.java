package org.tothought.web.email.abstracts;

public class AbstractMailMessage {

	
}
